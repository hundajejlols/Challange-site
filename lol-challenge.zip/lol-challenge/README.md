# Wyścig na Szczyt — LoL Challenge

Strona challenge'u: 4 świeże konta, 100 gier rankingowych na EUNE, wygrywa najwyższa ranga.

## Jak wrzucić na GitHub + Vercel

1. Załóż nowe repozytorium na GitHubie (np. `lol-challenge`).
2. Wrzuć tam **wszystkie pliki z tego folderu** (możesz przeciągnąć je w przeglądarce: *Add file → Upload files*).
3. Wejdź na [vercel.com](https://vercel.com), zaloguj się GitHubem, kliknij **Add New → Project**, wybierz repo `lol-challenge` i kliknij **Deploy**. Nic nie konfigurujesz — to zwykła strona statyczna.
4. Gotowe — dostaniesz link typu `lol-challenge.vercel.app`.

## Jak aktualizować wyniki

Edytujesz **tylko plik `data.js`**:

- ksywki i Riot ID (`imie`, `riotId` — format `Nazwa#TAG`),
- rangę (`tier`, `dywizja`, `lp`),
- bilans (`wygrane`, `przegrane`), `kda`, `mainChamp`, `rola`, `motto`,
- `historia` — dopisuj migawkę rangi co ~10 gier, z tego rysuje się wykres formy na karcie gracza.

Po edycji zrób commit i push (albo edytuj `data.js` bezpośrednio na GitHubie przez ołówek ✏️) — Vercel sam przebuduje stronę w ~30 sekund.

## Co jest na stronie

- **Drabinka** — animowany „wyścig" Iron → Challenger, żeton każdego gracza wisi na wysokości jego rangi + LP; lider dostaje koronę.
- **Karty graczy** — zdjęcie, a po najechaniu (na telefonie: tapnięciu) pełne staty, wykres formy i link do OP.GG.
- **Tabela wyników** — miejsce, ranga, LP, bilans, winrate, postęp gier.
- **Wyróżnienia** — Lider, najlepszy winrate, Grinder, maszyna KDA i… Wagon.
- **Zasady + stawka** — edytowalne w `data.js`.
